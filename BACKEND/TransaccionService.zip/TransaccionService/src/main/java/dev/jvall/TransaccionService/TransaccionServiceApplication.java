package dev.jvall.TransaccionService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TransaccionServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(TransaccionServiceApplication.class, args);
	}

}
