package dev.jvall.generatepdf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GeneratepdfApplication {

	public static void main(String[] args) {
		SpringApplication.run(GeneratepdfApplication.class, args);
	}

}
