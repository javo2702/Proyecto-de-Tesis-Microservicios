package dev.jvall.ValoracionService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ValoracionServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ValoracionServiceApplication.class, args);
	}

}
