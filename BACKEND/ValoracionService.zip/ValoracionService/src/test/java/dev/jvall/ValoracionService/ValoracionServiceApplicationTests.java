package dev.jvall.ValoracionService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ValoracionServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
